import styles from './ChangePassword.module.scss';
import classNames from 'classnames/bind';

const cx = classNames.bind(styles);

function ChangePassword() {
    return <div>Đổi mật khẩu</div>;
}

export default ChangePassword;
